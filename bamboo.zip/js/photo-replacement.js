
document.getElementById('avatar').addEventListener('change', function () {
    document.getElementById('photoForm').submit();
});